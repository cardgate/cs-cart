<?php
$paymentcode = 'sofortbanking';
$filename = 'cardgatesofortbanking';
$redirect = true;

include_once 'cardgate/base.php';
?>