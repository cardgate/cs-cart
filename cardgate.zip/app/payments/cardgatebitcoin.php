<?php
$paymentcode = 'bitcoin';
$filename = 'cardgatebitcoin';
$redirect = true;

include_once 'cardgate/base.php';
?>