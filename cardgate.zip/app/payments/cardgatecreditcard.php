<?php
$paymentcode = 'creditcard';
$filename = 'cardgatecreditcard';
$redirect = true;

include_once 'cardgate/base.php';
?>