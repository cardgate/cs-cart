<?php
$paymentcode = 'directdebit';
$filename = 'cardgatedirectdebit';
$redirect = true;

include_once 'cardgate/base.php';
?>