<?php
$paymentcode = 'afterpay';
$filename = 'cardgateafterpay';
$redirect = true;

include_once 'cardgate/base.php';
?>