<?php
$paymentcode = 'paypal';
$filename = 'cardgatepaypal';
$redirect = true;

include_once 'cardgate/base.php';
?>