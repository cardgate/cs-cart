<?php
$paymentcode = 'banktransfer';
$filename = 'cardgatebanktransfer';
$redirect = true;

include_once 'cardgate/base.php';
?>