<?php
$paymentcode = 'generic';
$filename = 'cardgategeneric';
$redirect = true;

include_once 'cardgate/base.php';
?>