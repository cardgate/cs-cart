<?php
$paymentcode = 'bancontact';
$filename = 'cardgatebancontact';
$redirect = true;

include_once 'cardgate/base.php';
?>