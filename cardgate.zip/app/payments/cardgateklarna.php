<?php
$paymentcode = 'klarna';
$filename = 'cardgateklarna';
$redirect = true;

include_once 'cardgate/base.php';
?>