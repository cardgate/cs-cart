<?php
$paymentcode = 'giropay';
$filename = 'cardgategiropay';
$redirect = true;

include_once 'cardgate/base.php';
?>