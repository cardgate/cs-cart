<?php
$paymentcode = 'ideal';
$filename = 'cardgateideal';
$redirect = true;

include_once 'cardgate/base.php';
?>