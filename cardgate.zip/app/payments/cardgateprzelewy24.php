<?php
$paymentcode = 'przelewy24';
$filename = 'cardgateprzelewy24';
$redirect = true;

include_once 'cardgate/base.php';
?>